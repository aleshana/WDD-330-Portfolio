window.addEventListener("keydown", playAudio);
let count = 10;
function playAudio(e){
    const key = document.querySelector(`.key[data-key="${e.keyCode}"]`);
    const audio = document.querySelector(`audio[data-key="${e.keyCode}"]`);
    key.setAttribute("id", e.keyCode);
    console.log(key);
    if (key){
        key.classList.add('playing');
        key.style.transform=`translateY(${count}px)`
        // count = count + 10;
        // console.log(key.style.transform);
        // if (count>100){
        //     key.style.transform=`translateY(0)`
        //     count = 0;
        // }
    }
    if(audio){
        audio.currentTime = 0;
        audio.play();
        audio.addEventListener("ended", ()=> 
        key.classList.remove("playing"));
    }
}

const keys = document.querySelectorAll('.key');
keys.forEach(key => key.addEventListener("transitionend", () =>
{
    count = count + 10;
    console.log(key.style.transform);
    if (count>100){
        key.style.transform=`translateY(0)`
        count = 0;
    }
}  ))

